#!/bin/bash

if [ -x ./mytar ];
then 
	# tenemos mytar ejecutable

	if [ -d ./tmp ]
	then
		# borramos el directorio tmp
		rm -Rf ./tmp
	fi

	# creamos el directorio tmp
	mkdir ./tmp

	# navegamos al directorio tmp
	cd tmp

	# Creamos los ficheros
	echo "Hello world\!" >> ./file1.txt
	# Head copia las primeras 10 filas
	head /etc/passwd >> ./file2.txt
	# -c selecciona la cantidad de bytes que copia
	head -c 1024 /dev/urandom >> ./file3.dat

	# ejecutamos mytar
	../mytar -cf ./filetar.mtar ./file1.txt ./file2.txt ./file3.dat 

	# creamos el directorio tmp
	mkdir ./out
	# copiamos fichero filetar.mtar creado al nuevo directorio
	cp ./filetar.mtar ./out
	# navegamos al directorio out
	cd out

	# descomprimimos el fichero filetar.mtar
	../../mytar -xf ./filetar.mtar
	
	# comprobamos las diferencias entre el [./file1.txt](extraido) y [../file1.txt](original)
	diff ./file1.txt ../file1.txt
	# en $? -eq 0 comprobamos el valor devuelto por la instruccion diff es 0 (no hay diferencia)
	if [ $? -eq 0 ]
	then
		#comprobamos las diferencias entre el [./file2.txt](extraido) y [../file2.txt](original)
		diff ./file2.txt ../file2.txt
		if [ $? -eq 0 ]
		then
			#comprobamos las diferencias entre el [./file3.txt](extraido) y [../file3.txt](original)
			diff ./file3.dat ../file3.dat
			if [ $? -eq 0 ]
			then
				cd ../..
				echo "Correct"
				exit 0
			else
				cd ../..
				echo "El archivo file3.dat ha cambiado"
				exit 1
			fi
		else
			cd ../..
			echo "El fichero file2.txt ha cambiado"
			exit 1
		fi
	else			
		cd ../..
		echo "El fichero file1.txt ha cambiado"
		exit 1
	fi
# no existe mytar
else 
	echo "No existe el ejecutable mytar"
fi





