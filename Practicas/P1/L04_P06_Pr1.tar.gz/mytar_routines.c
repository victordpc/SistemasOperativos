#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

extern char *use;

/** Copy nBytes bytes from the origin file to the destination file.
 *
 * origin: pointer to the FILE descriptor associated with the origin file
 * destination:  pointer to the FILE descriptor associated with the destination file
 * nBytes: number of bytes to copy
 *
 * Returns the number of bytes actually copied or -1 if an error occured.
 */
int copynFile(FILE * origin, FILE * destination, int nBytes) {
	int contador = 0;
	int leido = 0, escrito = 0;
	while (contador < nBytes && ((leido = getc(origin)) != EOF)) {
		if (leido == -1) {
			err(2, "Error while coping data between files");
			return -1;
		}
		if ((escrito = putc(leido, destination)) == leido) {
			contador++;
		} else {
			err(stderr, "Error while writing character %s", leido);
			return -1;
		}
	}

	// Complete the function
	return contador;
}

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor 
 * 
 * The loadstr() function must allocate memory from the heap to store 
 * the contents of the string read from the FILE. 
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc()) 
 * 
 * Returns: !=NULL if success, NULL if error
 */
char* loadstr(FILE * file) {

//	unsigned long ulSize = 0;  // Input File size
//	char* ucBuffer; // Buffer data
//	fseek(file, 0, SEEK_END); //Me muevo hasta el final del archivho
//	ulSize = ftell(file); //current file position --> Saca el tamaño en base a la posición
//	fseek(file, 0, SEEK_SET); //Cambia la posición en el fichero a la inicial
//	ucBuffer = (char*) malloc(ulSize); // memory allocation for ucBuffer var
//	fread(ucBuffer, 1, ulSize, file); // Read file
//	return ucBuffer;

	int contador = 0;
	int leido = 0;
	char* resultado = NULL;

	leido = getc(file);

	while ((leido != 0) && (leido != EOF)) {
		contador++;
		leido = getc(file);
	}
	contador++;

	resultado = malloc(contador);
	fseek(file, (0 - contador), SEEK_CUR);

	fread(resultado, 1, contador, file);

	// Complete the function
	return resultado;
}

/** Read tarball header and store it in memory.
 *
 * tarFile: pointer to the tarball's FILE descriptor 
 * nFiles: output parameter. Used to return the number 
 * of files stored in the tarball archive (first 4 bytes of the header).
 *
 * On success it returns the starting memory address of an array that stores 
 * the (name,size) pairs read from the tar file. Upon failure, the function returns NULL.
 */
stHeaderEntry* readHeader(FILE * tarFile, int *nFiles) {
	stHeaderEntry* resultado = NULL;
	int nr_files = 0, i = 0, j = 0;
	// Leetmos el número de ficheros
	fread(&nr_files, sizeof(int), 1, tarFile);

	//Reservams memoria para la cabecera
	resultado = malloc(sizeof(stHeaderEntry) * nr_files);
	//Comprobamos que no de error
	if (resultado == NULL) {
		err(2, "The memory allocation can't be done");
		fclose(tarFile);
		return NULL;
	}

	// Leemos la cabecera nFiles veces el tamaño de strHeaderEntry del tarFile,
	// almacenando en resultado
	for (i = 0; i < nr_files; ++i) {
		if ((resultado[i].name = loadstr(tarFile)) == NULL) {
			for (j = 0; j < i; j++)
				free(resultado[j].name);
			free(resultado);
			fclose(tarFile);
			return NULL;
		}
		fread(&resultado[i].size, sizeof(resultado[i].size), 1, tarFile);
	}

	(*nFiles) = nr_files;
	return resultado;
}

/** Creates a tarball archive 
 *
 * nfiles: number of files to be stored in the tarball
 * filenames: array with the path names of the files to be included in the tarball
 * tarname: name of the tarball archive
 * 
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First reserve room in the file to store the tarball header.
 * Move the file's position indicator to the data section (skip the header)
 * and dump the contents of the source files (one by one) in the tarball archive. 
 * At the same time, build the representation of the tarball header in memory.
 * Finally, rewind the file's position indicator, write the number of files as well as 
 * the (file name,file size) pairs in the tar archive.
 *
 * Important reminder: to calculate the room needed for the header, a simple sizeof 
 * of stHeaderEntry will not work. Bear in mind that, on disk, file names found in (name,size) 
 * pairs occupy strlen(name)+1 bytes.
 *
 */
int createTar(int nFiles, char *fileNames[], char tarName[]) {
	FILE* fileTar = NULL;
	FILE* fileEnt = NULL;
	int headerSize = 0;
	int i = 0, j = 0;
	int bytesCopiados;
	int tam = 0;

	//Reservamos espacio para las cabeceras (tamaño de strHeaderEntry * numero de ficheros)
	stHeaderEntry* cabeceras = (stHeaderEntry *) malloc(
			sizeof(stHeaderEntry) * nFiles);

	if ((fileTar = fopen(tarName, "w+")) == NULL) {
		err(2, "The input file %s could not be created", tarName);
		fclose(fileTar);
		free(cabeceras);
		return EXIT_FAILURE;
	}

	//Calculamos cabecera y rellenamos el array de cabeceras
//	headerSize = (sizeof(stHeaderEntry) * nFiles) + sizeof(int);
	headerSize = sizeof(int);
	for (i = 0; i < nFiles; ++i) {
		tam = strlen(fileNames[i]) + 1;
		headerSize += tam + sizeof(int);

		if ((cabeceras[i].name = malloc(tam)) == NULL) {
			err(2, "The memory allocation can't be done");
			fclose(fileTar);
			for (j = 0; j < i; ++j) {
				free(cabeceras[j].name);
			}
			free(cabeceras);
			return EXIT_FAILURE;
		}
		strcpy(cabeceras[i].name, fileNames[i]);
	}

	//Avanzamos el cursor del fichero para reservar espacio a la cabecera
	fseek(fileTar, headerSize, SEEK_CUR);

	//Recorremos los ficheros para escribirlos en el tar y los escibimos
	for (i = 0; i < nFiles; ++i) {
		if ((fileEnt = fopen(fileNames[i], "r")) == NULL) {
			err(2, "The input file %s could not be opened", fileNames[i]);
			fclose(fileTar);
			fclose(fileEnt);
			for (i = 0; i < nFiles; ++i) {
				free(cabeceras[i].name);
			}
			free(cabeceras);
			return EXIT_FAILURE;
		}

		bytesCopiados = copynFile(fileEnt, fileTar, INT_MAX);
		cabeceras[i].size = bytesCopiados;

//		printf("%s", cabeceras[i].name);
//		printf("%d", cabeceras[i].size);

		fclose(fileEnt);
	}

	// Volvemos al principio del fichero
//	fseek(file1, 0, SEEK_SET);
	rewind(fileTar);

	// Escribimos el número de ficheros
	fwrite(&(nFiles), sizeof(int), 1, fileTar);

//	// Escribimos las cabeceras en el fichero
	for (i = 0; i < nFiles; ++i) {
		fwrite(cabeceras[i].name, strlen(cabeceras[i].name) + 1, 1, fileTar);
		fwrite(&cabeceras[i].size, sizeof(cabeceras[i].size), 1, fileTar);
//		if (strlen(cabeceras[i].name) + 1
//				!= fwrite(cabeceras[i].name, strlen(cabeceras[i].name) + 1, 1,
//						fileTar)) {
//			err(2, "The file %s could not be writed", tarName);
//			fclose(fileTar);
//			for (i = 0; i < nFiles; ++i) {
//				free(cabeceras[i].name);
//			}
//			free(cabeceras);
//			return EXIT_FAILURE;
//		}
//		if (sizeof(cabeceras[i].size)
//				!= fwrite(&cabeceras[i].size, sizeof(cabeceras[i].size), 1,
//						fileTar)) {
//			err(2, "The file %s could not be writed", tarName);
//			fclose(fileTar);
//			for (i = 0; i < nFiles; ++i) {
//				free(cabeceras[i].name);
//			}
//			free(cabeceras);
//			return EXIT_FAILURE;
//		}
	}

	// Cerramos fichero
	fclose(fileTar);
	//Liberamos memoria de los nombres de los ficheros
	for (i = 0; i < nFiles; ++i) {
		free(cabeceras[i].name);
	}
	// Liberamos la memoria de la estructura de la cabecera
	free(cabeceras);

	return EXIT_SUCCESS;
}

/** Extract files stored in a tarball archive
 *
 * tarName: tarball's pathname
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE.
 * (macros defined in stdlib.h).
 *
 * HINTS: First load the tarball's header into memory.
 * After reading the header, the file position indicator will be located at the
 * tarball's data section. By using information from the
 * header --number of files and (file name, file size) pairs--, extract files
 * stored in the data section of the tarball.
 *
 */
int extractTar(char tarName[]) {
	FILE* fileTar = NULL;
	FILE* fileSal = NULL;
	int i = 0;
	int numFicheros = 0;
	int bytesCopiados = 0;
	stHeaderEntry* cabeceras;

	// Abrimos el fichero MyTar
	if ((fileTar = fopen(tarName, "r")) == NULL) {
		err(2, "The input file %s could not be created", tarName);
		fclose(fileTar);
		return EXIT_FAILURE;
	}

	// Llamamos a la función que lee la cabecera de un MyTar
	if ((cabeceras = readHeader(fileTar, &numFicheros)) == NULL) {
		err(2, "The input file %s can't be extracted", tarName);
		fclose(fileTar);
		return EXIT_FAILURE;
	}

	// Leemos los datos de cada fichero y lo creamos en el disco
	for (i = 0; i < numFicheros; ++i) {
//		printf("%s", cabeceras[i].name);
//		printf("%d", cabeceras[i].size);

		if ((fileSal = fopen(cabeceras[i].name, "w+")) == NULL) {
			err(2, "The input file %s could not be created", cabeceras[i].name);
			return EXIT_FAILURE;
		}
		bytesCopiados = copynFile(fileTar, fileSal, cabeceras[i].size);

		if (bytesCopiados != cabeceras[i].size) {
			err(2, "Error while extracting file %s", cabeceras[i].name);
			return EXIT_FAILURE;
		}
		fclose(fileSal);
	}

	fclose(fileTar);
	for (i = 0; i < numFicheros; ++i) {
		free(cabeceras[i].name);
	}
	free(cabeceras);
	// Complete the function
	return EXIT_SUCCESS;
}
